/**!
	NOM DU MODULE
	Description du module

	@contributors: Geoffrey Crofte (Alsacréations), Guillaume Focheux (Alsacréations)
	@date-created: 2015-03-26
	@last-update: 2015-03-26
 */
 
;(function($) {

	// Code is jQuery

})(jQuery);